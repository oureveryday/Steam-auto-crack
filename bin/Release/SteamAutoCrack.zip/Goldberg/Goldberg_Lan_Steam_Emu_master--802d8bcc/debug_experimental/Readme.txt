This is the debug experimental build. Note that it creates a huge STEAM_LOG.txt file where the game runs and will probably make the game lag so only use this to debug issues.
